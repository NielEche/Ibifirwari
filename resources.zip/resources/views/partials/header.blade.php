<header class="bg-transparent top-0 left-0 w-full z-10">
    <div class="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div class="flex justify-center">
            <img src="https://res.cloudinary.com/nieleche/image/upload/v1706619116/IBIFIBGWHITE_wcgwlk.png" class="size-32" alt="">
        </div>
    </div>
</header>
